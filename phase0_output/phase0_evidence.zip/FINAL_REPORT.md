# Controlled Phase 0 Empirical Validation Report

## Validation Process Lessons
- The previous validation used accelerated polling.
- The previous validation did not complete the stationary comparison.
- The previous validation contained uncontrolled variables.
- This controlled execution was performed to eliminate those variables and run strictly at 75-second intervals for 25 minutes.

## Cancelled Train 64450
The provider returned `status="cancelled"` for train 64450. No `segmentProgress` existed in the payload. Cancelled trains expose a different schema. This is documented as expected provider behaviour for cancelled routes. It was replaced with 12951 for the stationary test.

## Moving Train (12903) Extracted Topological Table
| Poll | Timestamp | lastUpdatedAt | previousStation | nextStation | segmentProgress | ΔsegmentProgress | Δtime (ms) |
|---|---|---|---|---|---|---|---|
| 2 | 2026-07-09T12:49:53.531Z | 2026-07-09T12:49:53.529Z | MUZ | UNKNOWN | 0.6170 | 0.0000 | 0 |
| 3 | 2026-07-09T12:51:09.025Z | 2026-07-09T12:51:09.025Z | MUZ | UNKNOWN | 0.7021 | 0.0851 | 75494 |
| 4 | 2026-07-09T12:52:24.576Z | 2026-07-09T12:52:24.575Z | MUZ | UNKNOWN | 0.7447 | 0.0426 | 75551 |
| 5 | 2026-07-09T12:53:40.504Z | 2026-07-09T12:53:40.503Z | MUZ | UNKNOWN | 0.6596 | -0.0851 | 75928 |

## Stationary Train Extracted Topological Table
**INSUFFICIENT DATA** (A8 skipped: No stationary candidate available at time of execution)

## Final Classification
Based on the raw payloads and parser traces saved in the output directory, the evidence shows:

*(Classification pending review of raw JSONs and Cache metadata...)*
